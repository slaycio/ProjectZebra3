/**
 * 
 */
/**
 * @author p
 *
 */
package pl.altoriis.projectzebra3.datamodel;